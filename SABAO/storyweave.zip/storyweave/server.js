const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');

const app = express();
const PORT = 3000;

app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

let users = [];

app.post('/login', (req, res) => {
  const { email, password } = req.body;
  const user = users.find(u => u.email === email && u.password === password);
  if (user) {
    res.send(`<h2>Welcome, ${user.username || email}!</h2><a href="/login.html">Logout</a>`);
  } else {
    res.send('<h2>Invalid credentials</h2><a href="/login.html">Try again</a>');
  }
});

app.post('/register', (req, res) => {
  const { username, email, password } = req.body;
  const userExists = users.some(u => u.email === email);
  if (userExists) {
    res.send('<h2>Email already registered</h2><a href="/register.html">Try again</a>');
  } else {
    users.push({ username, email, password });
    res.send('<h2>Registration successful</h2><a href="/login.html">Login now</a>');
  }
});

app.post('/reset', (req, res) => {
  const { oldPassword, newPassword } = req.body;
  const user = users.find(u => u.password === oldPassword);
  if (user) {
    user.password = newPassword;
    res.send('<h2>Password updated</h2><a href="/login.html">Login</a>');
  } else {
    res.send('<h2>Old password incorrect</h2><a href="/reset.html">Try again</a>');
  }
});

app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
